<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>留言管理系統</title>
</head>
<body>

<?php

session_start();
if(isset($_SESSION["login"])){
echo "<a href='admin.php'>回首頁</a>";
echo "<h3>使用者留言內容</h3>";
$link1=mysqli_connect('localhost','root','hanna870926','comment');
$data1="SELECT * from comment1 order by gTime desc";


$result1=mysqli_query($link1,$data1);


for($i=1;$i<=mysqli_num_rows($result1);$i++){
 $row=mysqli_fetch_assoc($result1);

?>
      <table border="1">
            <tr>
              <td >留言主題</td>
              <td><?php echo $row['gSubject']?></td>
            </tr>
            <tr>
              <td width="25%">暱稱</td>
              <td width="75%"><?php echo $row['gName']?></td>
            </tr>
            <tr>
              <td>留言時間</td>
              <td><?php echo $row['gTime']?></td>
            </tr>
            <tr>
              <td>性別</td>
              <td><?php echo $row['gGender']?></td>
            </tr>
            <tr>
              <td>留言內容</td>
              <td><?php echo $row['gContent']?></td>
            </tr>
            <tr>
              <td>功能</td>
              <td><?php echo "<a href='del.php?no=".$row['no']."'>刪除</a>";?>
              <?php echo "<a href='update.php?no=".$row['no']."' class='reply'>回覆</a>";?></td>
            </tr>
            <tr>
              <td>已回覆的內容</td>
              <td><?php echo $row['reply']?></td>
            </tr>
      </table>
<br />

<?php } 

}else{
	echo "<h1>非法進入!</h1>";
	echo "<a href='title.php'>回到登入網站</a>";
}

?>

<style>
h1{
  font-family: Microsoft JhengHei;
}
h3{
  font-family: Microsoft JhengHei;
  font-size: 32px;
}
body{
    background-image: url(back.jpg);
    background-size: 1600px 730px;
}  
a{
  text-decoration: none;
  letter-spacing: 2px;
  font-size: 25px;
  font-family: Microsoft JhengHei;
  font-weight: bold;
  float: right;
  background: #fff;
  color: #000;
  cursor: pointer;
  border:2px #000 solid;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
  border:2px #fff solid;
}
table{
  font-family: Microsoft JhengHei;
  font-size: 23px;
}
tr:nth-child(even) {
    background: #EEFFBB
}
tr:nth-child(odd) {
    background-color: #FAFAFA;
}

td:hover {
    background-color: #E6FBFF;
}
.reply{
  margin-right: 10px;
}
</style>

</body>
</html>