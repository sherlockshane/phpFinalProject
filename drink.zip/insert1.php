<?php

$link=mysqli_connect('localhost','root','hanna870926','comment');
date_default_timezone_set('Asia/Taipei');
$gName=$_GET['gName'];
$gGender=$_GET['gGender'];
$gSubject=$_GET['gSubject'];
$gContent=$_GET['gContent'];
$gTime = date("Y:m:d H:i:s");

$SQLinsert="INSERT into comment1(gName, gGender, gSubject, gContent, gTime) VALUES ('$gName','$gGender','$gSubject','$gContent','$gTime')";

if(isset($gName)){
  mysqli_query($link,$SQLinsert);
  header("Location:comment.php");
}

?>