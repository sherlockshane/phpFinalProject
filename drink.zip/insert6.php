<?php

$username=$_GET["username"];
$name=$_GET["50"];
$score=$_GET["myRange"];

$link=@mysqli_connect('localhost','root','hanna870926','score');   
$SQLCreate="INSERT into score3(user_name,name,score) VALUES ('$username','$name','$score')";

if($result=mysqli_query($link,$SQLCreate)){
	header("Location: score3.php");
}else{
	echo "評分失敗!!";
}

?>