<!DOCTYPE HTML>
<html>
<form action="checkuser.php" method="post">
<head>
<title>登入</title>
<link href="title.css" rel="stylesheet">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

</head>
<body>

<div class="wrap">
<div class="header">
<img src="logoword.jpg" width=450 height=75 class="nuk">
<input type="button" value="公告" onclick=location.href="message.php" class="ad">
<input type="button" value="留言" onclick=location.href="comment.php" class="comment">
<input type="button" value="評分" onclick=location.href="scoreswitch.php" class="score">
<br/>
</div>	
<div class="text">
<p>歡迎使用訂飲料管理系統^o^</p>
<span>-你說想喝飲料但又不想自己買...</span><br/>
<span>快來試試我們貼心的系統，飲料不用自己買\( ^ω^)/</span>
</div><br/>
<img src="2.PNG" class="image">
<div class="message warning">	
<img src="1.PNG">
<div class="inset">
	<div class="login-head">
		<h1>登入</h1> 			
	</div>
		<form>
			<li>
				<input type="text" placeholder="帳號" name="id" required="required">
			</li>
				<div class="clear"> </div>
			<li>
				<input type="password" placeholder="密碼" name="pwd">
			</li>
			<div class="clear"> </div>
			<div class="submit">
				<input type="submit" value="Sign in">
				
						  <div class="clear"></div>	
			</div>
				
		</form>
		</div>					
	</div>
	</div>
	<div class="clear"> </div>
</div>	

</form>
</body>
</html>