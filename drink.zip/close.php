<!DOCTYPE html>
<html lang="en">
<script type="text/javascript">
window.open("close.html", '_self');
window.close();
</script> 
</html>