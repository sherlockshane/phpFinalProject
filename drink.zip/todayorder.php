<!DOCTYPE html>
<html>
<head>
	<title>今日訂單</title>
</head>
<body>

<?php

session_start();

echo "<a href='admin.php'>回首頁</a>";

date_default_timezone_set('Asia/Taipei');
$day=date("Y-m-d");

if(isset($_SESSION["login"])){
	
	$link=mysqli_connect('localhost','root','hanna870926','order');
	$SQL="SELECT * FROM order1 WHERE day='$day' order by name";
	$SQL1="SELECT user_name, sum(price*count) as sum FROM order1 WHERE day='$day' GROUP BY user_name";
	$SQL2="SELECT name, sum(count) as sum FROM order1 WHERE day='$day' GROUP BY name";
  	//echo "<div class='data'>";
	
	echo "<h3>"."今日被訂購的飲料統計(".$day.")"."</h3>";
	echo "<div class='left'>";
	echo "<h3>"."迷客夏"."</h3>";
	echo "<table border='1'>";
	echo "<th>"."訂購者名稱"."</th><th>"."飲料名稱"."</th><th>"."甜度"."</th><th>"."冰塊"."</th><th>"."單杯價格"."</th><th>"."訂購的數量"."</th></tr>";
	if($result=mysqli_query($link,$SQL)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["sugar"]."</td><td>".$row["ice"]."</td><td>".$row["price"]."</td><td>".$row["count"]."</td>";
			echo "</tr>";
		}
  	}
  	if($result1=mysqli_query($link,$SQL1)){
		while($row=mysqli_fetch_assoc($result1)){
			$sum=$row["sum"];
			$name=$row["user_name"];
			echo "<tr><td colspan=8 align=right>";   
			echo $name."的總金額 = NT$".$sum."元</td>";
		}
		echo "</table>";
  	}
  	
  	//echo "</br>";


  	echo "<table border='1'>";
  	echo "<h4>"."迷客夏各飲料的總訂購數量"."</h4>";
	echo "<th>"."飲料名稱"."</th><th>"."訂購的總數量"."</th></tr>";
  	if($result=mysqli_query($link,$SQL2)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["name"]."</td><td>".$row["sum"]."</td>";
			echo "</tr>";
		}
		echo "</table>";
  	}

  	echo "</div>";

  	echo "<div class='center'>";
  	$link=mysqli_connect('localhost','root','hanna870926','order');
	$SQL="SELECT * FROM order2 WHERE day='$day' order by name";
	$SQL1="SELECT user_name, sum(price*count) as sum FROM order2 WHERE day='$day' GROUP BY user_name";
	$SQL2="SELECT name, sum(count) as sum FROM order2 WHERE day='$day' GROUP BY name";
  	//echo "<div class='data'>";
	echo "<h3>"."50嵐"."</h3>";
	echo "<table border='1'>";
	echo "<th>"."訂購者名稱"."</th><th>"."飲料名稱"."</th><th>"."甜度"."</th><th>"."冰塊"."</th><th>"."單杯價格"."</th><th>"."訂購的數量"."</th></tr>";
	if($result=mysqli_query($link,$SQL)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["sugar"]."</td><td>".$row["ice"]."</td><td>".$row["price"]."</td><td>".$row["count"]."</td>";
			echo "</tr>";
		}
  	}
  	if($result1=mysqli_query($link,$SQL1)){
		while($row=mysqli_fetch_assoc($result1)){
			$sum=$row["sum"];
			$name=$row["user_name"];
			echo "<tr><td colspan=8 align=right>";   
			echo $name."的總金額 = NT$".$sum."元</td>";
		}
		echo "</table>";
  	}

  	echo "<h4>"."50嵐各飲料的總訂購數量"."</h4>";
  	echo "<table border='1'>";
	echo "<th>"."飲料名稱"."</th><th>"."訂購的總數量"."</th></tr>";
  	if($result=mysqli_query($link,$SQL2)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["name"]."</td><td>".$row["sum"]."</td>";
			echo "</tr>";
		}
		echo "</table>";
  	}

  	echo "</div>";

  	echo "<div class='right'>";
  	$link=mysqli_connect('localhost','root','hanna870926','order');
	$SQL="SELECT * FROM order3 WHERE day='$day' order by name";
	$SQL1="SELECT user_name, sum(price*count) as sum FROM order3 WHERE day='$day' GROUP BY user_name";
	$SQL2="SELECT name, sum(count) as sum FROM order3 WHERE day='$day' GROUP BY name";
  	//echo "<div class='data'>";
	echo "<h3>"."麻古茶坊"."</h3>";
	echo "<table border='1'>";
	echo "<th>"."訂購者名稱"."</th><th>"."飲料名稱"."</th><th>"."甜度"."</th><th>"."冰塊"."</th><th>"."單杯價格"."</th><th>"."訂購的數量"."</th></tr>";
	if($result=mysqli_query($link,$SQL)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["sugar"]."</td><td>".$row["ice"]."</td><td>".$row["price"]."</td><td>".$row["count"]."</td>";
			echo "</tr>";
		}
  	}
  	if($result1=mysqli_query($link,$SQL1)){
		while($row=mysqli_fetch_assoc($result1)){
			$sum=$row["sum"];
			$name=$row["user_name"];
			echo "<tr><td colspan=8 align=right>";   
			echo $name."的總金額 = NT$".$sum."元</td>";
		}
		echo "</table>";
  	}

  	echo "<h4>"."麻古茶坊各飲料的總訂購數量"."</h4>";
  	echo "<table border='1'>";
	echo "<th>"."飲料名稱"."</th><th>"."訂購的總數量"."</th></tr>";
  	if($result=mysqli_query($link,$SQL2)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["name"]."</td><td>".$row["sum"]."</td>";
			echo "</tr>";
		}
		echo "</table>";
  	}

  	echo "</div>";
}else{
  	echo "<h1>非法進入!</h1>";
 	echo "<a href='title.php'>回到登入網站</a>";
}
	
?>

<style>
body{
	background-image: url(back.jpg);
    background-size: 1600px 750px;
    font-family: Microsoft JhengHei;
    font-size: 20px;
}	
.left{
	float: left;
	width: 32%;
	margin:5px;
	
	/*display: flex;
    align-items: center;
	justify-content: center;*/
}
.center{
	float: left;
	width: 32%;
	margin:5px;
	/*margin: 0 auto;
	font-size: 21px;*/
}
.right{
	float: left;
	width: 32%;
	margin:5px;
	
	/*display: flex;
    align-items: center;
	justify-content: center;*/
}
a{
  text-decoration: none;
  letter-spacing: 2px;
  font-size: 25px;
  font-family: Microsoft JhengHei;
  font-weight: bold;
  float: right;
  background: #fff;
  color: #000;
  cursor: pointer;
  border:2px #000 solid;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
  border:2px #fff solid;
}

tr:nth-child(even) {
    background: #EEFFBB
}
tr:nth-child(odd) {
    background-color: #FAFAFA;
}

td:hover {
    background-color: #E6FBFF;
}

</style>

</body>
</html>