<meta charset="utf-8">

<?php

$no=$_GET["no"];

$link=@mysqli_connect('localhost','root','hanna870926','order');     

$SQLDelete="DELETE FROM order3 WHERE no=$no";
$result=mysqli_query($link,$SQLDelete);
header("Location: macu.php");

mysqli_close($link);

?>