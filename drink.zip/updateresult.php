<?php

$number=$_POST["number"];
$content=$_POST["Content"];


$link=@mysqli_connect('localhost','root','hanna870926','comment');     

$SQLUpdate="UPDATE comment1 SET reply='$content' WHERE no=$number";
$result=mysqli_query($link,$SQLUpdate);


header("Location: rootcontent.php");

mysqli_close($link);

?>