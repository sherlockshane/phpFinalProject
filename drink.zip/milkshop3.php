<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="milkshop.css">
  <title>迷客夏</title>
</head>
<body>

<?php

session_start();

$link=@mysqli_connect('localhost','root','hanna870926','drink'); 

$SQL="SELECT * FROM drink2";

$i=0;

if($result=mysqli_query($link,$SQL)){
  while($row=mysqli_fetch_assoc($result)){
  
    $dname[$i]=$row["name"]."</h3>";   
    $Mprice[$i]=$row["price1"];
    $Lprice[$i]=$row["price2"];
    $i++;
  }
}

mysqli_close($link);

?>  

  <div class="wrap">
    <div class="header">
      <img src="milkshop.jpg" width="250" height="150">
      <span class="title"><marquee direction="right" width="350" bgcolor="#CCFF99">飲料價目表</marquee></span>
   
      <img class="nuk" src="nuk.png" width="120" height="120">
      <div class="rank">
      <?php 

      $link=@mysqli_connect('localhost','root','hanna870926','order');
      $SQL="SELECT name FROM order1 group by name order by sum(count) desc LIMIT 3";

      echo "<h1>"."飲料排行榜"."</h1>";
      $i=1;
      if($result=mysqli_query($link,$SQL)){
	        while($row=mysqli_fetch_assoc($result)){
		        echo "Top".$i.": ";
		        $i=$i+1;
		        echo $row["name"]."</br>";
	        }
      }

      ?>
</div>
      <div class="clear"></div>
    </div>
    <div class="center">
     <div class="content">
      <p class="menu">迷客夏菜單</p> 
      <p class="form">訂購頁面</p>
     </div> 
     <div class="clear"></div>
      <div class="contentleft">
        <ul class="nav">
          <li class="product">
            
            <?php  

            for($i=0;$i<23;$i++){
            echo "<h3 class='inline-block'>".$dname[$i]."</h3>";
            echo"<div class='price'>";
            if(isset($Mprice[$i])){
              echo"<span class='Mprice'>"."M"." ".$Mprice[$i]."</span>";
            }
            if(isset($Lprice[$i])){
              if(isset($Mprice[$i])){
                echo"<span class='Lprice'>"."L"." ".$Lprice[$i]."</span>";
              }else{
                echo"<span class='Lprice1'>"."L"." ".$Lprice[$i]."</span>";
              } 
            }
            echo"</div>";
            echo"<hr style='margin: 0px; border-bottom: 0px;'>";
            }

            echo "<h3 class='inline-block'>".$dname[23]."</h3>";
            echo"<div class='price'>";
            if(isset($Mprice[23])){
              echo"<span class='Mprice'>"."M"." ".$Mprice[23]."</span>";
            }
            if(isset($Lprice[23])){
              if(isset($Mprice[23])){
                echo"<span class='Lprice'>"."L"." ".$Lprice[23]."</span>";
              }else{
                echo"<span class='Lprice1'>"."L"." ".$Lprice[23]."</span>";
              } 
            }
            echo"</div>";

            ?>

          </li>
        </ul>
      </div>
      <div class="contentright">
        <ul class="nav">
          <li class="product">

            <?php  

            for($i=24;$i<46;$i++){
            echo "<h3 class='inline-block'>".$dname[$i]."</h3>";
            echo"<div class='price'>";
            if(isset($Mprice[$i])){
              echo"<span class='Mprice'>"."M"." ".$Mprice[$i]."</span>";
            }
            if(isset($Lprice[$i])){
              if(isset($Mprice[$i])){
                echo"<span class='Lprice'>"."L"." ".$Lprice[$i]."</span>";
              }else{
                echo"<span class='Lprice1'>"."L"." ".$Lprice[$i]."</span>";
              }
            }
            echo"</div>";
            echo"<hr style='margin: 0px; border-bottom: 0px;'>";
            }

            echo "<h3 class='inline-block'>".$dname[46]."</h3>";
            echo"<div class='price'>";
            if(isset($Mprice[46])){
              echo"<span class='Mprice'>"."M"." ".$Mprice[46]."</span>";
            }
            if(isset($Lprice[46])){
              if(isset($Mprice[46])){
                echo"<span class='Lprice'>"."L"." ".$Lprice[46]."</span>";
              }else{
                echo"<span class='Lprice1'>"."L"." ".$Lprice[46]."</span>";
              }
            }
            echo"</div>";

            ?>

          </li>
        </ul>
      </div>     
    </div>     
      <div class="order">
        <ul class="nav">
          <li class="product1">
          
          <form action="insert.php" method="get">

<h3>訂單</h3>

<?php


$link=@mysqli_connect('localhost','root','hanna870926','drink');  

$SQL="SELECT * FROM drink2";
$result = mysqli_query($link,$SQL); 

echo "<select name='milkshop'>"; 
while($row=mysqli_fetch_assoc($result)){
	echo "<option value = ".$row['name'].">".$row['name']."</option>"; 
}
mysqli_close($link);
echo "</select>";
echo "<br/>";

?>

大小杯 : 中杯(M)<input type=radio name='size' value='中杯'>
		    大杯(L)<input type=radio name='size' value='大杯'>
<br/>

冰塊 : 正常<input class='ice' type=radio name='ice' value='正常'>
                  少冰<input type=radio name='ice' value='少冰'>
                  去冰<input type=radio name='ice' value='去冰'>
<br/>

甜度 : 正常<input class='sugar' type=radio name='sugar' value='正常'>
                  少糖<input type=radio name='sugar' value='少糖'>
                  半糖<input type=radio name='sugar' value='半糖'>
                  微糖<input type=radio name='sugar' value='微糖'>
                  無糖<input type=radio name='sugar' value='無糖'>
                  
<br/>

數量 : <input type=text name='Quantity' class="num">
<br/>

信箱 : 
<input type='mail' class="text" name="mail">
※ 飲料若訂購成功會寄信通知您喔!! 
<br/> 
<font color="red">( 每次訂購都要填信箱!!  請輸入一樣的信箱地址喔!! )</font>
<br/> 
<input type='submit' value='訂購' class="button">

<h3>購物車</h3>
<?php

date_default_timezone_set('Asia/Taipei');
$day=date("Y-m-d");
$x=$_SESSION["username"];

$link=@mysqli_connect('localhost','root','hanna870926','order');
$SQL="SELECT * FROM order1 WHERE user_name='$x' and day='$day'";
$SQL1="SELECT sum(price*count) as sum FROM order1 WHERE user_name='$x' and day='$day'";


echo "<table border='1'>";
echo "<tr><th>"."使用者姓名"."</th><th>"."飲料名稱"."</th><th>"."大小杯"."</th><th>"."單杯價格"."</th><th>"."數量"."</th><th>"."甜度"."</th><th>"."冰塊"."</th><th>"."功能"."</th></tr>";
if($result=mysqli_query($link,$SQL)){
	while($row=mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["size"]."</td><td>".$row["price"]."</td><td>".$row["count"]."</td><td>".$row["sugar"]."</td><td>".$row["ice"]."</td><td>"."<a href='delete.php?no=".$row['no']."'>刪除</a>"."</td>";
		echo "</tr>";
	}
}

if($result1=mysqli_query($link,$SQL1)){
	while($row=mysqli_fetch_assoc($result1)){
		$sum=$row["sum"];
		echo "<tr><td colspan=8 align=right>";   
		echo "總金額 = NT$".$sum."元</td>";
	}
	echo "<tr><td colspan=8 align=right>";
	echo "<a href='detail.php'>結帳請點我</a></tr>";
}

echo "</table>";

mysqli_close($link);

?>
          
          </li>
        </ul>
      </div>
      <div class="clear"></div> 
  </div>
</body>
</html>

<style>

tr:nth-child(even) {
    background: #CCFF99
}
tr:nth-child(odd) {
    background-color: #FAFAFA;
}

td:hover {
    background-color: #E6FBFF;
}

</style>