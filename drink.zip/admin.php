<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>後臺分析</title>
</head>
<body>

<?php

session_start();

if(isset($_SESSION["login"])){
echo "<div class='wrap'>";
echo "<a href='logout.php'>登出</a>";
echo "<h2>後臺分析</h2>";
echo "<div class='left'>";
echo "(1)訂購飲料的統整資料</br>";
echo "</br>";
echo "<input type='button' value='訂購飲料' class='drink' onclick=location.href='link.php'><br/>";
echo "</br>";
echo "</br>";
echo "(2)飲料評分的統整資料</br>";
echo "</br>";
echo "<input type='button' value='飲料評分' class='score' onclick=location.href='linkscore.php'><br/>";
echo "</br>";
echo "</div>";
echo "<div class='right'>";
echo "(3)留言評論管理</br>";
echo "</br>";
echo "<input type='button' value='評論' class='content' onclick=location.href='rootcontent.php'><br/>";
echo "</br>";
echo "</br>";
echo "(4)今日的訂單</br>";
echo "</br>";
echo "<input type='button' value='訂單' class='list' onclick=location.href='todayorder.php'><br/>";
echo "</br>";
echo "</div>";
echo "</div>";
}else{
	echo "<h1>非法進入!</h1>";
	echo "<a href='title.php'>回到登入網站</a>";
}

?>

<style>
a{
    color: #000;
    font-size: 25px;
    font-family: Microsoft JhengHei;
    float: right;
    background: #fff;
    text-decoration: none;
    cursor: pointer;
    font-weight: bold;
    border:2px #000 solid;
    
}
a:hover{
  background: #000;
    color: #fff;
    border-radius: 6px;
    border:2px #fff solid;
  
}
h1{
    font-family: Microsoft JhengHei;
}
body{
    background-image: url(back.jpg);
    background-size: 1600px 730px;
}
.wrap{
    font-family: Microsoft JhengHei;
    font-size: 35px;
}
.left{
    text-align: center;
    float: left;
    width: 50%;
}
.right{
    text-align: center;
    float: left;
    width: 50%;
}
h2{
    letter-spacing: 5px;
    text-align: center;
}
input{
    font-family: Microsoft JhengHei;
    font-size: 26px;
    cursor: pointer;
}
.drink{
    width: 170px;
    height: 55px;
    color: #fff;
    background-color: #003C9D;
    border-radius: 30px;
}
.drink:hover{
    color: #003C9D;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #003C9D solid;
}
.score{
    width: 170px;
    height: 55px;
    color: #fff;
    background-color: #FF8800;
    border-radius: 30px;
}
.score:hover{
    color: #FF8800;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #FF8800 solid;
}
.content{
    width: 170px;
    height: 55px;
    color: #fff;
    background-color: #00DD00;
    border-radius: 30px;
}
.content:hover{
    color: #00DD00;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #00DD00 solid;
}
.list{
    width: 170px;
    height: 55px;
    color: #fff;
    background-color: #CC00FF;
    border-radius: 30px;
}
.list:hover{
    color: #CC00FF;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #CC00FF solid;
}
</style>
</body>
</html>