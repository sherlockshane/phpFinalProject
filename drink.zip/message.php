<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="message.css">
    <title>最新公告</title>
</head>
<body>

<div class="header"><h1>貼心提醒 : 點擊logo可以進入粉專查看詳細資訊喔!!<a href="title.php" class="title">點我回首頁</a></h1></div>

<div class='milkshop'>
<a href="https://www.facebook.com/milkshoptea/">
<img src="milkshop.jpg" width=460 height=300></a>
<h1>迷客夏最新消息活動板</h1>	
</div>

<div class='ran'> 
<a href="http://50lan.com/web/news.asp">
<img src="50.jpg"  width='460px' height="300"></a>
<h1>50嵐最新消息活動板</h1>	
</div>

<div class='shop3'>
<a href="https://www.facebook.com/pg/macu2008.tw/posts/?ref=page_internal">
<img src="macu.jpg" width=460 height=300></a>	
<h1>麻古茶坊最新消息活動板</h1>
</div>

<div class='ad1'>

<img src="news.jpg" width='290px' height="390">
</div>
<div class="ad2">
<img src="黃金烏龍.gif" width='310px' height="390">
</div>
<div class="ad3">
<img src="mango.png" width='490px' height="390">
</div>
<div class="clear"></div>
</body>
</html>