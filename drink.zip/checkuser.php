<?php

session_start();

$id = $_POST["id"];
$pwd = $_POST["pwd"];

if($id=="root" && $pwd=="root"){
	$_SESSION["login"]="root";
	header("Location:admin.php");
}elseif (isset($_POST["id"]) && $pwd=="drink"){
	$_SESSION["username"]=$_POST["id"];
	header("Location:switch.php");
}else{
	echo "帳號密碼錯誤<br/>";
	echo "將在2秒後返回登入頁面";
	header("refresh:2;url=title.php");
}

?>