<meta charset="utf-8">
<form action="insert.php" method="get">

<h3>請輸入使用者的名字:</h3>
<input type=text name=username>

<h3>訂單</h3>

<?php

$link=@mysqli_connect('localhost','root','hanna870926','drink');  

$SQL="SELECT * FROM drink2";
$result = mysqli_query($link,$SQL); 

echo "<select name='milkshop'>"; 
while($row=mysqli_fetch_assoc($result)){
	echo "<option value = ".$row['name'].">".$row['name']."</option>"; 
}
mysqli_close($link);
echo "</select>";
echo "<br/>";

?>

大小杯 : 中杯(M)<input type=radio name='size' value='中杯'>
		大杯(L)<input type=radio name='size' value='大杯'>
<br/>

冰塊 : 正常<input class='ice' type=radio name='ice' value='正常'>
                  少冰<input type=radio name='ice' value='少冰'>
                  去冰<input type=radio name='ice' value='去冰'>
<br/>

甜度 : 正常<input class='sugar' type=radio name='sugar' value='正常'>
                  少糖<input type=radio name='sugar' value='少糖'>
                  半糖<input type=radio name='sugar' value='半糖'>
                  微糖<input type=radio name='sugar' value='微糖'>
                  無糖<input type=radio name='sugar' value='無糖'>
                  
<br/>

數量 : <input type=text name='Quantity'>
<br/>

<input type='submit' value='訂購'>
<br/>

<h3>購物車</h3>

<?php

$link=@mysqli_connect('localhost','root','hanna870926','order');
$SQL="SELECT * FROM order1";
$SQL1="SELECT sum(price*count) as sum FROM order1";


echo "<table border='1'>";
echo "<th>"."使用者姓名"."</th><th>"."飲料名稱"."</th><th>"."大小杯"."</th><th>"."單杯價格"."</th><th>"."數量"."</th><th>"."甜度"."</th><th>"."冰塊"."</th><th>"."功能"."</th></tr>";
if($result=mysqli_query($link,$SQL)){
	while($row=mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["size"]."</td><td>".$row["price"]."</td><td>".$row["count"]."</td><td>".$row["sugar"]."</td><td>".$row["ice"]."</td><td>"."<a href='delete.php?no=".$row['no']."'>刪除</a>"."</td>";
		echo "</tr>";
	}
}

if($result1=mysqli_query($link,$SQL1)){
	while($row=mysqli_fetch_assoc($result1)){
		$sum=$row["sum"];
		echo "<tr><td colspan=8 align=right>";   
		echo "總金額 = NT$".$sum."元</td>";
	}
	echo "<tr><td colspan=8 align=right>";
	echo "<a href='detail.php'>結帳請點我</a></tr>";
}

echo "</table>";

mysqli_close($link);

?>