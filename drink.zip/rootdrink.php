<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>迷客夏飲料受歡迎程度</title>
</head>
<body>

<?php 

session_start();
if(isset($_SESSION["login"])){
$link2=mysqli_connect('localhost','root','hanna870926','order');
$data2="SELECT sum(count) as sum,name from order1 group by name";
$result=mysqli_query($link2,$data2);


$rows = array();
//flag is not needed
$flag = true;
$table = array();
$table['cols'] = array(


    array('label' => 'name',   'type' => 'string'),
    array('label' => 'sum',    'type' => 'number'));
   
    $rows = array();
while($r = mysqli_fetch_assoc($result)) {
    $temp = array();

    $temp[] = array('v' => (string)$r['name']); 
    $temp[] = array('v' => (int)$r['sum']);
    $rows[] = array('c' => $temp);
}
$table['rows'] = $rows;
$jsonTable = json_encode($table);
}else{
	echo "<h1>非法進入!</h1>";
	echo "<a href='title.php'>回到登入網站</a>";
}

?>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);

      function drawChart() {
        //var data = google.visualization.DataTable(<?=$jsonTable?>);
var data = new google.visualization.DataTable(<?php echo $jsonTable; ?>);
        var options = {
          title: '迷客夏飲料受歡迎程度表',
          titleTextStyle:{
  			fontName: '微軟正黑體',
  			fontSize: 30,
          },
          is3D: 'true',
          width: 700,
          height: 500,
          legend:{position: 'top', textStyle: {fontName:'微軟正黑體',color: 'black', fontSize: 24}},
          pieSliceText:'percentage',
          pieSliceTextStyle:{
          	fontName: '微軟正黑體', fontSize: 25
          },
          chartArea:{
            left: 20
          },
        }; 

        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
       </script>
  

    <div id="chart_div" style="width: 900px; height: 500px;"></div>
  
<?php

session_start();

if(isset($_SESSION["login"])){
  $link=mysqli_connect('localhost','root','hanna870926','order');
	$SQL="SELECT  name, sum(count) as sum FROM order1 group by name order by sum(count)";
  echo "<div class='data'>";
	echo "<h3>"."被訂過的飲料統計資料"."</h3>";
	echo "<table border='1'>";
	echo "<th>"."飲料名稱"."</th><th>"."被訂購過的數量"."</th></tr>";
	if($result=mysqli_query($link,$SQL)){
		while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["name"]."</td><td>".$row["sum"]."</td>";
			echo "</tr>";
		}
  }
  echo "</div>";
}else{
  echo "<h1>非法進入!</h1>";
  echo "<a href='title.php'>回到登入網站</a>";
}

?>
  
<style>
body{
  background-image: url(http://ku.90sjimg.com/element_origin_min_pic/16/06/11/20575c048c0441d.jpg);
	background-size: 1600px 730px;
}
.data{
  float: right;
  margin-top: -500px;
  text-align: center;
  margin-right: 150px;
  font-size: 35px;
  font-family: Microsoft JhengHei;
}
h1{
  font-family: Microsoft JhengHei;
}
a{
    color: #000;
    font-size: 20px;
    font-family: Microsoft JhengHei;
    font-weight: bold;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
}

tr:nth-child(even) {
    background: #CCFF99
}
tr:nth-child(odd) {
    background-color: #FAFAFA;
}

td:hover {
    background-color: #E6FBFF;
}

</style>

</body>
</html>