<?php

$link=mysqli_connect('localhost','root','hanna870926','comment');

$no=$_GET["no"];

$SQLdel="DELETE FROM comment1 WHERE no=$no";

$result=mysqli_query($link,$SQLdel);
header("Location: rootcontent.php");

mysqli_close($link);

?>