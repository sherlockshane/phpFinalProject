<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>訂購明細(50嵐)</title>
</head>
<body>
<div class="wrap">
	<div class="left">
	<img src="https://lookin-img.pixfs.net/upload/images/news_5__929026260.jpg" width=380 height=480>
	</div>
	<div class="right">
	<img src="https://images.dappei.com/uploads/tag/image/52913/large_712bb7139813707a.jpg" width=300 height=480>
    </div>
    <div class="center">	
<h3>訂購明細(50嵐)</h3>

<?php

session_start();

date_default_timezone_set('Asia/Taipei');
$day=date("Y-m-d");
$x=$_SESSION["username"];

$link=@mysqli_connect('localhost','root','hanna870926','order');     
$SQL="SELECT * FROM order2 WHERE user_name='$x' and day='$day'";
$SQL1="SELECT sum(price*count) as sum FROM order2 WHERE user_name='$x' and day='$day'";


echo "<table border='4'>";
echo "<th>"."使用者姓名"."</th><th>"."飲料名稱"."</th><th>"."大小杯"."</th><th>"."單杯價格"."</th><th>"."數量"."</th><th>"."甜度"."</th><th>"."冰塊"."</th></tr>";
if($result=mysqli_query($link,$SQL)){
	while($row=mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["size"]."</td><td>".$row["price"]."</td><td>".$row["count"]."</td><td>".$row["sugar"]."</td><td>".$row["ice"]."</td>";
		echo "</tr>";
	}
}

if($result1=mysqli_query($link,$SQL1)){
		while($row=mysqli_fetch_assoc($result1)){
			$sum=$row["sum"];
			$name=$row["user_name"];
			echo "<tr><td colspan=8 align=right>";   
			echo "總金額 = NT$".$sum."元</td>";
		}
		echo "</table>";
}
echo "</br>";
echo "<a href='mail1.php'>確認無誤</a></br>";
echo "<p>※ 點下確認無誤後，系統會寄飲料訂購成功通知信喔!!</p>";


?>

<a href="50.php">點我回飲料選購頁面</a><br/><br/>
<a href="title.php">點我回首頁</a>
</div>
    
</div>
<style>
a{
  text-decoration: none;
  letter-spacing: 2px;
  font-size: 20px;
  font-family: Microsoft JhengHei;
  font-weight: bold;
  background: #fff;
  color: #000;
  cursor: pointer;
  border:2px #000 solid;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
  border:2px #fff solid;
}
.wrap{
	width: 100%;
}
body{
    background-image: url(back.jpg);
    background-size: 1600px 730px;
}
.left{
	float: left;
	width: 29%;
	display: flex;
    align-items: center;
	justify-content: center;
}
.center{
	float: left;
	width: 42%;
	margin: 0 auto;
	font-size: 21px;
}
.right{
	float: right;
	width: 29%;
	display: flex;
    align-items: center;
	justify-content: center;
}
img{
	margin-top: 20%;
}
h3{
	font-family: Microsoft JhengHei;
	text-align: center;
}
table{
	font-family: Microsoft JhengHei;
	border-collapse: collapse;
	margin: 0 auto;
}
td:nth-child(even){
	background: #DDDDDD;
}
td:nth-child(odd){
	background: #FAFAFA;
}
tr,td{
	border: 3px solid #0000AA;
}
td:hover{
	background: #77FFEE;
}
</style>
</body>
</html>