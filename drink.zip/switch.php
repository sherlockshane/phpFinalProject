<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>選擇飲料店</title>
</head>
<body>

<?php

date_default_timezone_set('Asia/Taipei');
$datetime= date("Y F d G:i:s");

if (date("G")<=11) {
    //date("G")>=11
    //date("G")>=12 && date("G")<=24 || date("G")>=0 && date("G")<=7
    //date("G")<=11
    echo "<center><img src='tenor.gif' width=700></center>";
    echo "<h2>此時間點不能訂飲料喔!!<br/></h2>";
    echo "<h2>將在5秒後返回首頁</h2>";
    header("refresh:5;url=title.php");
    echo "<br/>";
}
else{

echo "<h1 class='drink'>請選擇飲料店</h1>"; 
echo "<div class='wrap'>";
   
echo "<div class='milkshop'>
<a href='milkshop3.php'>
<img src='milkshop.jpg' width=460 height=300></a>
<h1>迷客夏</h1>	
</div>

<div class='ran'> 
<a href='50.php'>
<img src='50.jpg' width=460 height=300></a>
<h1>50嵐</h1>	
</div>

<div class='shop3'>
<a href='macu.php'>
<img src='macu.jpg' width=460 height=300></a>	
<h1>麻古茶坊</h1>
</div>    
</div>";
}

?>

<style>
.wrap{
    margin-top: 145px;
    margin-left: 30px;
}
h1{
    font-family: Microsoft JhengHei, serif;
    text-align: center;
}
.drink{
    font-size: 40px;
}
.milkshop{
    font-family: Microsoft JhengHei, serif;
    height: 400px;
 	width: 480px ;
    float:left;
    text-align: center;
}
.milkshop img:hover{
    border: 5px solid #000;
}
.ran{
    font-family: Microsoft JhengHei, serif;
 	height: 400px;
 	width: 480px;
     float:left;
     text-align: center;
 }
 .ran img:hover{
    border: 5px solid #000;
}
.shop3{
	font-family: Microsoft JhengHei, serif;
    height: 400px;
    width: 480px;
    float:left;
    text-align: center;
}
.shop3 img:hover{
    border: 5px solid #000;
}
body{
	background-image: url(back.jpg);
	background-size: 1600px 730px;
}
h2{
    font-family: Microsoft JhengHei, serif;
    font-size: 45px;
    text-align: center;
}
</style>

</body>
</html>