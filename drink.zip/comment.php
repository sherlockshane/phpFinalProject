<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>留言</title>
</head>
<body>
<a href="title.php">點我回首頁</a>
<form action="insert1.php" method="get">

<h3>留下您的寶貴意見吧~</h3>
名稱：<input type="text" name="gName"></br>
性別：男<input type="radio" name="gGender" value="男">
    女<input type="radio" name="gGender" value="女">
</br>
留言主題：<input type="text" name="gSubject" align="center"><br/>
<br/>
留言內容：
<textarea cols="30" rows="5" name="gContent"></textarea></br>
<input type="submit" value="留言" class="text">
</form>

<h3>留言區</h3>
<?php

$link1=mysqli_connect('localhost','root','hanna870926','comment');
$data1="SELECT distinct * from comment1 order by gTime desc";


$result1=mysqli_query($link1,$data1);


for($i=1;$i<=mysqli_num_rows($result1);$i++){
 $row=mysqli_fetch_assoc($result1);

?>
      <table border="1">
            <tr>
              <td >留言主題</td>
              <td><?php echo $row['gSubject']?></td>
            </tr>
            <tr>
              <td width="25%">暱稱</td>
              <td width="75%"><?php echo $row['gName']?></td>
            </tr>
            <tr>
              <td>留言時間</td>
              <td><?php echo $row['gTime']?></td>
            </tr>
            <tr>
              <td>性別</td>
              <td><?php echo $row['gGender']?></td>
            </tr>
            <tr>
              <td>留言內容</td>
              <td><?php echo $row['gContent']?></td>
            </tr>
            <tr>
              <td>回覆內容</td>
              <td><?php echo $row['reply']?></td>
            </tr>
         
        </table>
<br />

<?php } ?>

<style>
a{
  text-decoration: none;
  letter-spacing: 2px;
  font-size: 25px;
  font-family: Microsoft JhengHei;
  font-weight: bold;
  float: right;
  background: #fff;
  color: #000;
  border:2px #000 solid;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
  border:2px #fff solid;
}
body{
    background-image: url(back.jpg);
    background-size: 1600px 730px;
    font-family: Microsoft JhengHei;
    font-size: 20px;
}
h3{
  font-family: Microsoft JhengHei;
  font-size: 30px;
}
.text{
  font-family: Microsoft JhengHei;
  width: 70px;
  height: 30px;
  letter-spacing: 3px;
  border-radius: 10px;
  cursor: pointer;
}
textarea{
  vertical-align: middle;
}
table{
  font-size: 22px;
}
</style>

</body>
</html>