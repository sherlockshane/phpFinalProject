<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>迷客夏評分數據</title>
</head>
<body>


<?php

session_start();

if(isset($_SESSION["login"])){
$link=@mysqli_connect('localhost','root','hanna870926','score');
$SQL="SELECT * FROM score1 order by name ";
$SQL1="SELECT name, round(cast((sum(score)/count(name)) as decimal),4)as avg , count(name) as count FROM score1 group by name order by count(name) desc";

echo "<div class='mk'>";
echo '<h3>迷客夏飲料評分表</h3>';
echo "<table border='1'>";
echo "<th>"."飲料名稱"."</th><th>"."評分者姓名"."</th><th>"."分數"."</th></tr>";
if($result=mysqli_query($link,$SQL)){
	while($row=mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>".$row["name"]."</td><td>".$row["user_name"]."</td><td>".$row["score"]."</td>";
		echo "</tr>";
	}
}
echo "</table>";
echo "</div>";
//echo "</br>";

echo "<div class='score'>";
//echo "</br>";
echo "<h3>飲料評分數據統計</h3>";
echo "<table border='1'>";
echo "<th>"."飲料名稱"."</th><th>"."評分平均值"."</th><th>"."被評分的次數"."</th></tr>";
if($result1=mysqli_query($link,$SQL1)){
	while($row1=mysqli_fetch_assoc($result1)){
		echo "<tr>";
		echo "<td>".$row1["name"]."</td><td>".$row1["avg"]."</td><td>".$row1["count"]."</td>";
		echo "</tr>";
	}
}else{
	echo "fail";
}
echo "</table>";
echo "</div>";
mysqli_close($link);
}
else{
	echo "<h1>非法進入!</h1>";
	echo "<a href='title.php'>回到登入網站</a>";
}

?>
<style>
.mk{
	float: left;
	
	margin-right:20px;
	 
	
}
.score{
	float: left;
	
	margin-right:20px;
	
}


a{
    color: #000;
    font-size: 20px;
    font-family: Microsoft JhengHei;
    font-weight: bold;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
}
h1{
    font-family: Microsoft JhengHei;
}
body{
	background-image: url(back.jpg);
	background-size: 1600px 730px;
}
h3{
	font-family: Microsoft JhengHei;
	font-size: 35px;
}
table{
	font-family: Microsoft JhengHei;
	font-size: 25px;
}
tr:nth-child(even) {
    background: #CCFF99
}
tr:nth-child(odd) {
    background-color: #FAFAFA;
}

td:hover {
    background-color: #E6FBFF;
}

</style>


<?php  
//session_start();
if(isset($_SESSION["login"])){
$link2=mysqli_connect('localhost','root','hanna870926','score');
$data2="SELECT name,  round(cast((sum(score)/count(name)) as decimal),4)as avg , count(name) as count FROM score1 group by name order by count(name) desc";
$result2=mysqli_query($link2,$data2);

    

$rows = array();
//flag is not needed
$flag = true;
$table = array();
$table['cols'] = array(


    array('label' => 'name',   'type' => 'string'),
    array('label' => 'avg',    'type' => 'number'));
   
    $rows = array();
while($r = mysqli_fetch_assoc($result2)) {
    $temp = array();

    $temp[] = array('v' => (string)$r['name']); 
    $temp[] = array('v' => (int)$r['avg']);
    $rows[] = array('c' => $temp);
}
$table['rows'] = $rows;
$jsonTable = json_encode($table);

}
else{
	echo "<h1>非法進入!</h1>";
	echo "<a href='title.php'>回到登入網站</a>";
}
?>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);

      function drawChart() {
        //var data = google.visualization.DataTable(<?=$jsonTable?>);
var data = new google.visualization.DataTable(<?php echo $jsonTable; ?>);
        var options = {
          title: '迷客夏評分人氣表',
          titleTextStyle:{
  			fontName: '微軟正黑體',
  			fontSize: 30,
          },
          is3D: 'true',
          width: 700,
          height: 500,
          legend:'none',
         
          chartArea:{
            left: 80
          },
        }; 

        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
      
       </script>
   	<div id="chart_div" style="width: 500px; height: 400px; float: left;"></div>

</body>
</html>