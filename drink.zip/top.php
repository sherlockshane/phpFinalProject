<?php

$link=@mysqli_connect('localhost','root','hanna870926','order');
$SQL="SELECT name FROM order2 group by name order by sum(count) desc LIMIT 3";

echo "<h3>"."飲料排行榜"."</h3>";
$i=1;
if($result=mysqli_query($link,$SQL)){
	while($row=mysqli_fetch_assoc($result)){
		echo "Top".$i.": ";
		$i=$i+1;
		echo $row["name"]."</br>";
	}
}

?>