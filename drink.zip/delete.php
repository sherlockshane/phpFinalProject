<meta charset="utf-8">

<?php

$no=$_GET["no"];

$link=@mysqli_connect('localhost','root','hanna870926','order');       

$SQLDelete="DELETE FROM order1 WHERE no=$no";
$result=mysqli_query($link,$SQLDelete);
header("Location: milkshop3.php");

mysqli_close($link);

?>