<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>50嵐評分</title>
</head>
<body>

<form action="insert5.php" method="get">
<a href='title.php'>點我回首頁</a>
<h3>請輸入您的名稱:</h3>
<input type=text name=username>
<br/>
<h3>給50嵐飲料打個分吧!!</h3> 

<?php

$link=@mysqli_connect('localhost','root','hanna870926','drink');  

$SQL="SELECT * FROM drink";
$result = mysqli_query($link,$SQL); 

echo "<select name='50' style='width:200px;height:30px';>"; 
while($row=mysqli_fetch_assoc($result)){
	echo "<option value = ".$row['name'].">".$row['name']."</option>"; 
}
mysqli_close($link);
echo "</select>";
echo "<br/>";

?>    

<input type="range" name="myRange" min=0 max=10><br/>
<br/>
<input type="submit" value="提交" class="score">

<h3>飲料評分表</h3>
<h5>來看看大家給的飲料分數吧~</h5>

<?php

$link=@mysqli_connect('localhost','root','hanna870926','score');
$SQL="SELECT * FROM score2";

echo "<table border='1'>";
echo "<th>"."評分者姓名"."</th><th>"."飲料名稱"."</th><th>"."分數"."</th></tr>";
if($result=mysqli_query($link,$SQL)){
	while($row=mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>".$row["user_name"]."</td><td>".$row["name"]."</td><td>".$row["score"]."</td>";
		echo "</tr>";
	}
}

echo "</table>";

mysqli_close($link);

?>

</form>

<style>
  a{
  text-decoration: none;
  letter-spacing: 2px;
  font-size: 25px;
  font-family: Microsoft JhengHei;
  font-weight: bold;
  float: right;
  background: #fff;
  color: #000;
  cursor: pointer;
  border:2px #000 solid;
}
a:hover{
  background: #000;
  color: #fff;
  border-radius: 6px;
  border:2px #fff solid;
}
body{
    background-image: url(http://ku.90sjimg.com/element_origin_min_pic/16/06/11/20575c048c0441d.jpg);
    background-size: 1600px 730px;
}
h3,h5{
	font-family: Microsoft JhengHei;
	font-size: 25px;
}
table,select{
  font-family: Microsoft JhengHei;
  font-size: 20px;
}
.score{
  font-family: Microsoft JhengHei;
  width: 60px;
  height: 25px;
  cursor: pointer;
  border-radius: 50px;
}
.score:hover{
  background: #fff;
}
input[type="range"]{
  -webkit-appearance: none;
  overflow:hidden;   
  width:200px;
  height:20px;
  outline : none;      
  background: #DDDDDD;
  opacity: 0.9;
}
input[type="range"]::-webkit-slider-thumb{
  -webkit-appearance: none;
  position: relative;    
  width:10px;
  height:10px;
  background:#0000FF;
  border-radius:50%;
  transition:.2s;       
}
input[type="range"]::-webkit-slider-thumb:before,
input[type="range"]::-webkit-slider-thumb:after
{
  position: absolute;
  top: 3px;
  width: 2000px;          
  height: 4px;
  content:"";
  pointer-events: none;   
  transition:.2s;
}
input[type="range"]::-webkit-slider-thumb:before{
  left: -1997px;
  background: #f22;
}
input[type="range"]::-webkit-slider-thumb:after {
  left: 10px;
  background: #edc;
}
input[type="range"]:active::-webkit-slider-thumb:before,
input[type="range"]:active::-webkit-slider-thumb:after
{
  top: 6px;
}

input[type="range"]:active::-webkit-slider-thumb{
  width:16px;
  height:16px;
}

input[type="range"]:active::-webkit-slider-thumb:after {
  left: 16px;
}
</style>

</body>
</html>