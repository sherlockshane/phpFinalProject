<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>訂購飲料的統整資料</title>
</head>
<body>
 
<?php

echo "<div class='wrap'>";
echo "<h2>訂購飲料的統整資料</h2>";
echo "<div class='text'>";
echo "(1)迷客夏</br>";
echo "</br>";
echo "<input type='button' value='迷客夏的統整資料' class='drink' onclick=location.href='rootdrink.php'><br/>";
echo "</br>";
echo "(2)50嵐</br>";
echo "</br>";
echo "<input type='button' value='50嵐的統整資料' class='score' onclick=location.href='rootdrink2.php'><br/>";
echo "</br>";
echo "(3)麻古茶坊</br>";
echo "</br>";
echo "<input type='button' value='麻古茶坊的統整資料' class='content' onclick=location.href='rootdrink3.php'><br/>";
echo "</div>";
echo "</div>";

?>

<style>
body{
    background-image: url(back.jpg);
    background-size: 1600px 730px;
}  
.wrap{
    font-family: Microsoft JhengHei;
    font-size: 30px;
}
.text{
    text-align: center;
}
h2{
    letter-spacing: 5px;
    text-align: center;
}
input{
    font-family: Microsoft JhengHei;
    font-size: 26px;
    cursor: pointer;
}
.drink{
    width: 260px;
    height: 55px;
    color: #fff;
    background-color: #003C9D;
    border-radius: 30px;
}
.drink:hover{
    color: #003C9D;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #003C9D solid;
}
.score{
    width: 260px;
    height: 55px;
    color: #fff;
    background-color: #FF8800;
    border-radius: 30px;
}
.score:hover{
    color: #FF8800;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #FF8800 solid;
}
.content{
    width: 260px;
    height: 55px;
    color: #fff;
    background-color: #00DD00;
    border-radius: 30px;
}
.content:hover{
    color: #00DD00;
    background-color: #fff;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    border:2px #00DD00 solid;
}
</style>

</body>
</html>
