<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>選擇飲料店(評分)</title>
</head>
<body>
<h1 class="drink">請選擇飲料店(評分)</h1> 
<div class="wrap">
   
<div class='milkshop'>
<a href="score.php">
<img src="https://www.1111boss.com.tw/Upload/bossPic/1831_02.jpg" width=460 height=300></a>
<h1>迷客夏</h1>	
</div>

<div class='ran'> 
<a href="score2.php">
<img src="https://www.104.com.tw/upload1/custintroduce/L1_4/L2_3/13000000009023420170110010947top.jpg"  width='460px' height="300"></a>
<h1>50嵐</h1>	
</div>

<div class='shop3'>
<a href="score3.php">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiPtLVGrzFUxKzL16PB0mONizIBn_tFgVdNEFIfiVTHXB3cKnVQQ" width=460 height=300></a>	
<h1>麻古茶坊</h1>
</div>    
</div>
<style>
.wrap{
    margin-top: 145px;
    margin-left: 30px;
}
h1{
    font-family: Microsoft JhengHei, serif;
    text-align: center;
}
.drink{
    font-size: 40px;
}
.milkshop{
    font-family: Microsoft JhengHei, serif;
    height: 400px;
 	width: 480px ;
    float:left;
    text-align: center;
}
.milkshop img:hover{
    border: 5px solid #000;
}
.ran{
    font-family: Microsoft JhengHei, serif;
 	height: 400px;
 	width: 480px;
     float:left;
     text-align: center;
 }
 .ran img:hover{
    border: 5px solid #000;
}
.shop3{
	font-family: Microsoft JhengHei, serif;
    height: 400px;
    width: 480px;
    float:left;
    text-align: center;
}
.shop3 img:hover{
    border: 5px solid #000;
}
body{
	background-image: url(back.jpg);
	background-size: 1600px 730px;
}
</style>

</body>
</html>