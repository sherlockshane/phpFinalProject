<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>回覆</title>
</head>
<body>

<?php

$no=$_GET["no"];

$link=@mysqli_connect('localhost','root','hanna870926','comment');     

$SQLUpdate="SELECT * FROM comment1 WHERE no=$no";
$result=mysqli_query($link,$SQLUpdate);

//$SQL="SELECT * FROM user";

if($result=mysqli_query($link,$SQLUpdate)){
	while($row=mysqli_fetch_assoc($result)){
		echo "<form action='updateresult.php' method='post'>";
		//echo "編號:".$row["number"]."</br>";
		echo "<input type='hidden' value=".$row["no"]." name='number'>";
		echo "欲回覆內容:<input type=text name='Content'></br>";
		echo "<input type='submit' value='回覆' class='reply'>";
		echo "</form>";
	}
}


mysqli_close($link);

?>

<style>
body{
    background-image: url(back.jpg);
	background-size: 1600px 730px;
	font-family: Microsoft JhengHei;
    font-size: 25px;
} 
input{
	font-family: Microsoft JhengHei;
	font-size: 20px;
}
.reply{
	width: 70px;
    height: 35px;
	border: 0;
    color: #fff;
    background-color:#003C9D;
    border-radius: 10px;
    cursor: pointer;
}
.reply:hover{
	color: #003C9D;
    background: #fff;
    border:2px #003C9D solid;
}
</style>
</body>
</html>