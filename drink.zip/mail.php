<?php

session_start();

// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Taipei');
$day=date("Y-m-d");
$x=$_SESSION["username"];

$link=@mysqli_connect('localhost','root','hanna870926','order'); 
$SQL="SELECT distinct mail FROM order1 where user_name='$x' and day='$day'";
$result=mysqli_query($link,$SQL);
$row=mysqli_fetch_assoc($result);
$y=$row["mail"];

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                                       // Enable verbose debug output 
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 's3785066@gmail.com';                // SMTP username
    $mail->Password   = 's3781015';                    // SMTP password
    $mail->SMTPSecure = 'ssl';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('s3785066@gmail.com', 'Handsome Administrator');           
    $mail->addAddress($row["mail"], 'Customer');        
    //$mail->addAddress('ellen@example.com');               // Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');

    // Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true);                                    // Set email format to HTML
    $subject="=?UTF-8?B?".base64_encode($subject)."?="; 
    $mail->Subject = "Your drink has been ordered successfully!!";    
    $mail->Body    = "飲料訂購成功囉!! 飲料到時會再通知您";        
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo "飲料訂購成功信件已寄出!!</br>";
    echo "頁面將在5秒後返回首頁";
    header("refresh:5;url=title.php");
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>