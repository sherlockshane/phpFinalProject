<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	
</head>
<body>

<?php

session_start();

date_default_timezone_set('Asia/Taipei');

$username=$_SESSION["username"];
$name=$_GET["milkshop"];
$size=$_GET["size"];
$count=$_GET["Quantity"];
$sugar=$_GET["sugar"];
$ice=$_GET["ice"];
$mail=$_GET["mail"];
$day=date("Y:m:d H:i:s");

$link=@mysqli_connect('localhost','root','hanna870926','order');   
$link1=@mysqli_connect('localhost','root','hanna870926','drink');
$SQL="SELECT price1 FROM drink2 WHERE name='$name'";
$SQL2="SELECT price2 FROM drink2 WHERE name='$name'";
$SQL3="SELECT SUM(price) as sum FROM order1";

$size2=$size;

if($size2=="中杯"){
	$result= mysqli_query($link1,$SQL);
	while($row=mysqli_fetch_assoc($result)){
		$price=$row["price1"];
	}
}elseif($size2=="大杯"){
	$result= mysqli_query($link1,$SQL2); 
	while($row=mysqli_fetch_assoc($result)){
		$price=$row["price2"];		
	}
}

if($price==0){
	echo "不可以訂購這個飲料尺寸喔!!</br>";
	echo "將在2秒後返回訂購頁面";
	header("refresh:2;url=milkshop3.php");
}else{

$result1= mysqli_query($link,$SQL3); 
while($row=mysqli_fetch_assoc($result1)){
	$sum=$row["sum"];		
}

$SQLCreate="INSERT into order1(user_name,name,size,price,count,sugar,ice,day,mail) VALUES ('$username','$name','$size','$price','$count','$sugar','$ice','$day','$mail')";

if($result=mysqli_query($link,$SQLCreate)){
	header("Location: milkshop3.php");
}else{
	echo "加入購物車失敗!!";
}}
mysqli_close($link);

?>

<style>
body{
	background-image: url(back.jpg);
	background-size: 1600px 730px;
	font-family: Microsoft JhengHei;
	font-size: 30px;
}	
</style>

</body>
</html>